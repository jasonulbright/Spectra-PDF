import io
import os
import pickle
import shutil
import struct
import subprocess
import sys
import time
from io import BytesIO
from pathlib import Path
from threading import Thread
from unittest import mock

import helpers
import pytest
from PIL import Image, ImageChops, ImageSequence, UnidentifiedImageError

import pillow_heif
from pillow_heif import misc

os.chdir(os.path.dirname(os.path.abspath(__file__)))

pillow_heif.register_heif_opener()


HEAD_SIZE = misc.FileSource.HEAD_SIZE


@pytest.fixture
def file_reads():
    reads = []
    original_read_at = misc.FileSource.read_at
    original_read_head = misc.FileSource.read_head

    def read_at(self, offset, length):
        data = original_read_at(self, offset, length)
        reads.append((offset, len(data)))
        return data

    def read_head(self, fp):
        n_reads = len(reads)
        head = original_read_head(self, fp)
        del reads[n_reads:]  # how much of the head Pillow has in the buffer of the file depends on the Python version
        reads.append((0, len(head)))
        return head

    with (
        mock.patch.object(misc.FileSource, "read_at", read_at),
        mock.patch.object(misc.FileSource, "read_head", read_head),
    ):
        yield reads


def open_from_memory(path):
    return Image.open(BytesIO(Path(path).read_bytes()))


def info_without_depth(im):
    return {k: v for k, v in im.info.items() if k != "depth_images"}


def assert_no_byte_read_twice(file_reads, path):
    position = 0
    for offset, length in sorted(file_reads):
        assert offset >= position
        position = offset + length
    assert position <= os.path.getsize(path)


def assert_each_byte_read_once(file_reads, path):
    assert_no_byte_read_twice(file_reads, path)
    assert sum(length for _, length in file_reads) == os.path.getsize(path)


@pytest.mark.parametrize(
    "path",
    (
        "images/heif_other/pug.heic",
        "images/heif_other/cat.hif",
        "images/heif_special/xiaomi.heic",  # 188 KB of EXIF, it ends after the first 128 KB
    ),
)
def test_metadata_is_read_without_the_image_data(file_reads, path):
    with Image.open(Path(path)) as im:
        reads_at_open = list(file_reads)
        exif = im.getexif()
        im_memory = open_from_memory(path)
        assert exif == im_memory.getexif()
        assert info_without_depth(im) == info_without_depth(im_memory)
        assert (im.size, im.mode, im.n_frames) == (im_memory.size, im_memory.mode, im_memory.n_frames)
    assert file_reads == reads_at_open
    assert file_reads[0] == (0, HEAD_SIZE)
    assert_no_byte_read_twice(file_reads, path)
    assert sum(length for _, length in file_reads) < os.path.getsize(path) / 2


@pytest.mark.parametrize("path", ("images/heif_other/pug.heic", "images/heif_other/cat.hif"))
def test_load_reads_each_byte_once(file_reads, path):
    im = Image.open(Path(path))
    im.load()
    assert_each_byte_read_once(file_reads, path)
    assert im.tobytes() == open_from_memory(path).tobytes()


def test_file_object_is_read_at_once(file_reads):
    with open("images/heif_other/pug.heic", "rb") as fp:
        im = Image.open(fp)
    im.load()  # `fp` is closed already
    assert im.tobytes() == open_from_memory("images/heif_other/pug.heic").tobytes()
    assert not file_reads


def test_small_file_is_read_at_once(file_reads):
    path = "images/heif/zPug_3.heic"
    im = Image.open(Path(path))
    assert file_reads == [(0, os.path.getsize(path))]
    for frame in range(im.n_frames):
        im.seek(frame)
        im.load()
    assert file_reads == [(0, os.path.getsize(path))]


def test_load_after_close(file_reads, tmp_path, monkeypatch):
    with Image.open("images/heif_other/pug.heic") as im:
        pass
    monkeypatch.chdir(tmp_path)  # the path was relative
    im.load()
    monkeypatch.undo()
    assert im.tobytes() == open_from_memory("images/heif_other/pug.heic").tobytes()
    assert sum(length for _, length in file_reads) == os.path.getsize("images/heif_other/pug.heic")


def test_load_after_image_close(file_reads, tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    im = Image.open(path)
    reads_at_open = list(file_reads)
    im.close()
    path.unlink()  # nothing is read from the file once the image is closed
    with pytest.raises(ValueError, match="Operation on closed image"):
        im.load()
    assert file_reads == reads_at_open


def test_seek_after_image_close():
    im = Image.open(Path("images/heif_other/nokia/bird_burst.heic"))
    n_frames = im.n_frames
    im.seek(1)
    im.close()
    assert im.n_frames == n_frames
    with pytest.raises(ValueError, match="Operation on closed image"):
        im.seek(0)


@pytest.mark.skipif(os.name == "nt", reason="creating a symlink needs extra rights on Windows")
def test_load_after_close_path_with_symlink(tmp_path, monkeypatch):
    (tmp_path / "real" / "sub").mkdir(parents=True)
    shutil.copy("images/heif_other/pug.heic", tmp_path / "real" / "pug.heic")
    (tmp_path / "link").symlink_to(tmp_path / "real" / "sub")
    monkeypatch.chdir(tmp_path)
    with Image.open("link/../pug.heic") as im:  # `..` of the symlink is `real`, not `tmp_path`
        pass
    im.load()
    assert im.tobytes() == open_from_memory(tmp_path / "real" / "pug.heic").tobytes()


def test_file_changed_while_it_is_read(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    original = misc.FileSource._read  # pylint: disable=protected-access

    def read_while_written(self, fp, offset, length):  # another process writes the file meanwhile
        data = original(self, fp, offset, length)
        with open(path, "ab") as other:
            other.write(b"\0")
        return data

    with (
        Image.open(path) as im,
        mock.patch.object(misc.FileSource, "_read", read_while_written),
        pytest.raises(OSError, match="was changed after it was opened"),
    ):
        im.load()


@mock.patch("PIL.ImageFile.LOAD_TRUNCATED_IMAGES", True)
def test_file_read_short():
    original = misc.FileSource._read  # pylint: disable=protected-access

    def read_short(self, fp, offset, length):  # the file is shorter than it was when it was opened
        return original(self, fp, offset, length)[:-1]

    with (
        Image.open(Path("images/heif_other/pug.heic")) as im,
        mock.patch.object(misc.FileSource, "_read", read_short),
        pytest.raises(OSError, match="was changed after it was opened"),
    ):
        im.load()


def test_unpickled_image():
    with Image.open(Path("images/heif_other/cat.hif")) as im:
        unpickled = pickle.loads(pickle.dumps(im))
    assert (unpickled.n_frames, unpickled.is_animated, unpickled.tell()) == (1, False, 0)
    unpickled.seek(0)
    assert unpickled.tobytes() == open_from_memory("images/heif_other/cat.hif").tobytes()


def test_image_decoded_while_its_file_is_read():
    path = "images/heif_other/pug.heic"
    im = Image.open(Path(path))
    depth_image = im.info["depth_images"][0]
    original = misc.FileSource._read  # pylint: disable=protected-access
    errors = []

    def read_and_decode(self, fp, offset, length):  # e.g. a signal handler decodes another image of the file
        if not errors:
            with pytest.raises(RuntimeError, match="the file is being read by this thread") as e:
                depth_image.to_pillow()
            errors.append(e.value)
        return original(self, fp, offset, length)

    with mock.patch.object(misc.FileSource, "_read", read_and_decode):
        thread = Thread(target=im.load, daemon=True)  # a daemon: the test fails instead of hanging on a deadlock
        thread.start()
        thread.join(60)
    assert not thread.is_alive()
    assert errors
    assert im.tobytes() == open_from_memory(path).tobytes()


def test_image_decoded_while_its_file_is_read_for_another_thread():
    path = "images/heif_other/nokia/bird_burst.heic"
    original = misc.FileSource._read  # pylint: disable=protected-access
    errors, waiting = [], []

    with open(path, "rb") as fp:
        heif_file = pillow_heif.HeifFile(fp, lazy_read=True, filename=path)

        def read_and_decode(self, fp, offset, length):
            if not errors:
                waiting.append(Thread(target=heif_file[1].load, daemon=True))  # it waits for this read
                waiting[0].start()
                time.sleep(0.2)
                with pytest.raises(RuntimeError, match="the file is being read by this thread") as e:
                    heif_file[1].load()  # e.g. a signal handler decodes the image the other thread waits for
                errors.append(e.value)
            return original(self, fp, offset, length)

        with mock.patch.object(misc.FileSource, "_read", read_and_decode):
            reading = Thread(target=heif_file[0].load, daemon=True)  # daemons: a deadlock fails the test
            reading.start()
            reading.join(60)
            waiting[0].join(60)
    assert not reading.is_alive() and not waiting[0].is_alive()
    assert errors
    memory = pillow_heif.open_heif(Path(path).read_bytes())
    assert heif_file[0].data == memory[0].data and heif_file[1].data == memory[1].data


def test_file_changed_after_close(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        pass
    with open(path, "ab") as fp:
        fp.write(b"\0")
    with pytest.raises(OSError, match="was changed after it was opened"):
        im.load()


def test_file_attributes_changed_after_close(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        pass
    os.chmod(path, 0o600)  # these change the change time of the file, not its data
    os.link(path, tmp_path / "link.heic")
    im.load()
    assert im.tobytes() == open_from_memory("images/heif_other/pug.heic").tobytes()


def test_file_removed_after_close(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        pass
    path.unlink()
    with pytest.raises(FileNotFoundError):
        im.load()


def test_file_truncated_after_open(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        os.truncate(path, 300000)
        with pytest.raises(OSError, match="was changed after it was opened"):
            im.load()


def test_file_rewritten_before_load(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        path.write_bytes(Path("images/heif_other/cat.hif").read_bytes())  # the same file, Pillow still has it open
        with pytest.raises(OSError, match="was changed after it was opened"):
            im.load()


@pytest.mark.skipif(os.name == "nt", reason="a file cannot be removed while Pillow has it open on Windows")
def test_file_replaced_before_load(tmp_path):
    path = tmp_path / "pug.heic"
    shutil.copy("images/heif_other/pug.heic", path)
    with Image.open(path) as im:
        shutil.copy("images/heif_other/cat.hif", tmp_path / "cat.hif")
        os.replace(tmp_path / "cat.hif", path)
        im.load()
        assert im.tobytes() == open_from_memory("images/heif_other/pug.heic").tobytes()


def test_file_libheif_reads_only_from_memory():
    path = "images/heif_special/big_ftyp.heic"  # the `ftyp` box is bigger than the first 1 KB libheif requests
    with Image.open(Path(path)) as im:
        assert im.tobytes() == open_from_memory(path).tobytes()


def test_file_needed_in_many_parts(file_reads, tmp_path):
    path = tmp_path / "boxes.heic"  # libheif reads the header of every box: each part it needs costs a new parse
    path.write_bytes(Path("images/heif/zPug_3.heic").read_bytes() + b"\0\0\0\x08free" * 2_000_000)
    with Image.open(path) as im:
        assert len(file_reads) <= 6  # the first 128 KB, four parts, the rest of the file
        assert im.tobytes() == open_from_memory(path).tobytes()


@pytest.mark.skipif(sys.maxsize < 2**32, reason="Requires 64-bit Python")
def test_file_bigger_than_2_gib(file_reads, tmp_path):
    path = tmp_path / "big.heif"  # macOS fails one read of 2 GiB or more
    data = Path("images/heif/RGB_8__128x128.heif").read_bytes()
    size = 2**31 + 2**24
    with open(path, "wb") as f:
        f.write(data + struct.pack(">I4sQ", 1, b"free", size - len(data)))
        f.truncate(size)
    with Image.open(path) as im:
        im.load()
        assert im.tobytes() == open_from_memory("images/heif/RGB_8__128x128.heif").tobytes()
    assert max(length for _, length in file_reads) <= 2**30
    assert_each_byte_read_once(file_reads, path)


def test_file_of_a_file_system_in_memory():
    class InMemoryFile(io.BufferedIOBase):  # as pyfakefs does: the descriptor belongs to another file
        def __init__(self, data, fileno):
            super().__init__()
            self._data = BytesIO(data)
            self._fileno = fileno

        def fileno(self):
            return self._fileno

        def readable(self):
            return True

        def seekable(self):
            return True

        def read(self, size=-1):
            return self._data.read(size)

        def seek(self, offset, whence=0):
            return self._data.seek(offset, whence)

        def tell(self):
            return self._data.tell()

    with open("images/heif_other/cat.hif", "rb") as other:
        fp = InMemoryFile(Path("images/heif_other/pug.heic").read_bytes(), other.fileno())
        heif_file = pillow_heif.HeifFile(fp, lazy_read=True, filename="pug.heic")
        assert heif_file.size == open_from_memory("images/heif_other/pug.heic").size


def test_file_position_without_pread(monkeypatch):
    monkeypatch.delattr(os, "pread", raising=False)  # as on Windows
    with Image.open(Path("images/heif_special/xiaomi.heic")) as im:  # its EXIF ends after the first 128 KB
        assert im.fp.tell() == 0


def test_file_closed_while_it_is_read():
    path = "images/heif_other/pug.heic"
    im = Image.open(Path(path))
    original = misc.FileSource._read  # pylint: disable=protected-access

    def read_after_close(self, fp, offset, length):  # another thread leaves the `with` block meanwhile
        if fp is im.fp:
            fp.close()
        return original(self, fp, offset, length)

    with mock.patch.object(misc.FileSource, "_read", read_after_close):
        im.load()
    assert im.tobytes() == open_from_memory(path).tobytes()


@pytest.mark.skipif(not hasattr(os, "pread"), reason="without `pread` the file is read through its file object")
def test_file_closed_and_its_descriptor_reused_while_it_is_read(monkeypatch):
    path = "images/heif_other/pug.heic"
    im = Image.open(Path(path))
    fd = im.fp.fileno()
    pread = os.pread
    reused = []

    def pread_reused(descriptor, length, offset):  # another thread closes the file and opens another one meanwhile
        if descriptor == fd and not reused:
            other = os.open("images/heif_other/cat.hif", os.O_RDONLY)
            im.fp.close()
            os.dup2(other, fd)
            os.close(other)
            reused.append(fd)
        return pread(descriptor, length, offset)

    monkeypatch.setattr(os, "pread", pread_reused)
    try:
        im.load()
    finally:
        for descriptor in reused:
            os.close(descriptor)
    assert reused
    assert im.tobytes() == open_from_memory(path).tobytes()


def test_read_error_while_decoding_a_thumbnail():
    with Image.open(Path("images/heif_other/nokia/stereo_1200x800.heic")) as im:
        with (
            mock.patch.object(misc.FileSource, "read_at", side_effect=OSError("connection lost")),
            pytest.raises(OSError, match="connection lost"),
        ):
            im.draft(None, (240, 160))
        assert im.draft(None, (240, 160)) == ("RGB", (0, 0, 480, 320))


@pytest.mark.parametrize("path", (os.devnull, "empty"))
def test_special_files_are_read_at_once(file_reads, tmp_path, path):
    if path == "empty":
        path = tmp_path / "empty.heic"
        path.write_bytes(b"")
    with open(path, "rb") as fp, pytest.raises(ValueError):
        pillow_heif.HeifFile(fp, lazy_read=True, filename=str(path))
    assert not file_reads


def test_read_error_while_opening():
    original = misc.FileSource.read_at

    def read_at(self, offset, length):
        if offset >= HEAD_SIZE:
            raise OSError("connection lost")
        return original(self, offset, length)

    with mock.patch.object(misc.FileSource, "read_at", read_at), pytest.raises(UnidentifiedImageError):
        Image.open(Path("images/heif_special/xiaomi.heic"))  # its EXIF ends after the first 128 KB


def test_depth_image_outlives_the_image(file_reads):
    path = "images/heif_other/pug.heic"
    with Image.open(Path(path)) as im:
        depth_image = im.info["depth_images"][0]
    del im
    depth_memory = open_from_memory(path).info["depth_images"][0]
    assert depth_image.to_pillow().tobytes() == depth_memory.to_pillow().tobytes()
    assert_each_byte_read_once(file_reads, path)


def test_frames_after_the_file_is_closed(file_reads):
    path = "images/heif_other/nokia/bird_burst.heic"
    im = Image.open(Path(path))
    im_memory = open_from_memory(path)
    assert im.n_frames == im_memory.n_frames == 4
    for frame in range(im.n_frames):
        im.seek(frame)
        im_memory.seek(frame)
        assert im.tobytes() == im_memory.tobytes()
        assert im.fp is None
    assert sum(length for _, length in file_reads) == os.path.getsize(path)


def test_thumbnail_load_reads_the_rest_of_the_file(file_reads):
    path = "images/heif_special/200MP.heic"
    max_image_pixels = Image.MAX_IMAGE_PIXELS
    try:
        Image.MAX_IMAGE_PIXELS = None
        im = Image.open(Path(path))
        assert im.draft(None, (256, 256)) == ("RGB", (0, 0, 384, 512))
        im_memory = open_from_memory(path)
        im_memory.draft(None, (256, 256))
        assert im.tobytes() == im_memory.tobytes()
    finally:
        Image.MAX_IMAGE_PIXELS = max_image_pixels
    assert_each_byte_read_once(file_reads, path)


@pytest.mark.skipif(not helpers.hevc_enc(), reason="Requires HEVC encoder.")
def test_save_over_the_file_after_thumbnail(tmp_path):
    path = tmp_path / "frames.heic"
    frames = [  # the noise makes the frames bigger than the parts of the file that are read for the thumbnail
        ImageChops.add(
            Image.linear_gradient("L").rotate(90 * i).resize((512, 384)), Image.effect_noise((512, 384), 32), 1, -128
        ).convert("RGB")
        for i in range(3)
    ]
    frames[0].save(path, save_all=True, append_images=frames[1:], thumbnails=[256], quality=90)
    originals = [frame.copy() for frame in ImageSequence.Iterator(open_from_memory(path))]
    im = Image.open(path)
    im.thumbnail((64, 48))  # decodes the embedded thumbnail of the first frame
    im.save(path, save_all=True)  # Pillow empties the file before the frames are decoded
    with Image.open(path) as saved:
        assert saved.n_frames == 3
        for frame in (1, 2):  # these are read from the file only when they are saved
            saved.seek(frame)
            helpers.assert_image_similar(saved.convert("RGB"), originals[frame], 20)


def test_images_of_one_file_decoded_in_threads(file_reads):
    path = "images/heif_other/nokia/bird_burst.heic"
    with open(path, "rb") as fp:
        heif_file = pillow_heif.HeifFile(fp, lazy_read=True, filename=path)
        assert sum(length for _, length in file_reads) < os.path.getsize(path)
        decoded = {}

        def decode(index):
            decoded[index] = bytes(heif_file[index].data)

        threads = [Thread(target=decode, args=(i,)) for i in range(len(heif_file))]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
    heif_file_memory = pillow_heif.open_heif(path)
    assert [decoded[i] for i in range(len(heif_file))] == [bytes(i.data) for i in heif_file_memory]
    assert_each_byte_read_once(file_reads, path)


DECODE_WHILE_PARSING = """
import sys
import threading

from PIL import Image

import pillow_heif

pillow_heif.register_heif_opener()
errors = []
threading.excepthook = lambda args: errors.append(repr(args.exc_value))


def decode(path):
    for _ in range(3):
        with Image.open(path) as im:
            im.load()


def parse(path):
    while any(thread.is_alive() for thread in decoders):
        with Image.open(path) as im:
            im.getexif()


decoders = [threading.Thread(target=decode, args=(sys.argv[1],)) for _ in range(2)]
parsers = [threading.Thread(target=parse, args=(sys.argv[2],)) for _ in range(2)]
for thread in decoders + parsers:
    thread.start()
for thread in decoders + parsers:
    thread.join()
sys.exit("\\n".join(errors) or 0)
"""


def test_file_parsed_while_another_is_decoded():
    # libheif calls the reader of a file that is decoded without the GIL, and holds its lock for reading item data;
    # a parse in another thread holds the GIL and waits for that lock: a reader that needs the GIL hangs (PyPy)
    decoded = str(Path("images/heif_other/cat.hif").resolve())  # a grid, libheif decodes its tiles in threads
    parsed = str(Path("images/heif_special/xiaomi.heic").resolve())  # its EXIF is read at open
    result = subprocess.run(
        [sys.executable, "-c", DECODE_WHILE_PARSING, decoded, parsed], capture_output=True, text=True, timeout=60
    )
    assert result.returncode == 0, result.stderr
